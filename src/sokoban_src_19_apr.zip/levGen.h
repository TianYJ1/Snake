#pragma once
void generateSeed(char * seed, int difficul);
