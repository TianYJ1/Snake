#pragma once
int onKeyDown(int key);
int onKeyPressed(int key);
int onKeyUp(int key);
int onMouseWheel(float dir);
int onMouseClick(float x, float y);
int initEventManager();